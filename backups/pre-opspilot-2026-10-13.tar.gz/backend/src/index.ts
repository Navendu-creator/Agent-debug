import express from 'express';
import cors from 'cors';
import { config, assertRuntimeReady } from './config.js';
import { incidentsRouter } from './routes/incidents.js';
import { webhooksRouter } from './routes/webhooks.js';

const app = express();
app.use(cors({ origin: true }));
app.use(express.json({ limit: '1mb' }));

app.get('/health', (_req, res) => {
  const runtime = assertRuntimeReady();
  res.json({
    ok: true,
    service: 'debug-assist',
    repo: config.githubRepoUrl,
    dryRun: config.dryRun || (config.agentProvider === 'cursor' && !config.cursorApiKey),
    agent:
      config.agentProvider === 'cursor'
        ? { provider: 'cursor', model: config.cursorModel }
        : { provider: 'local', api: config.llmApi, model: config.llmModel, canOpenPR: Boolean(config.githubToken) },
    teamsConfigured: Boolean(config.teamsWebhookUrl),
    cursorConfigured: Boolean(config.cursorApiKey),
    warnings: runtime.warnings,
  });
});

app.use('/api/incidents', incidentsRouter);
app.use('/api/webhooks', webhooksRouter);

// Convenience alias matching the landing-page curl example
app.post('/incidents', (req, res, next) => {
  req.url = '/';
  incidentsRouter(req, res, next);
});

app.listen(config.port, () => {
  const runtime = assertRuntimeReady();
  console.log(`DebugAssist API listening on http://localhost:${config.port}`);
  console.log(`Repo: ${config.githubRepoUrl} @ ${config.githubRepoRef}`);
  for (const w of runtime.warnings) console.warn(`⚠ ${w}`);
});
