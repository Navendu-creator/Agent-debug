import 'dotenv/config';
import { tmpdir } from 'node:os';
import { join } from 'node:path';

function env(name: string, fallback = ''): string {
  return (process.env[name] ?? fallback).trim();
}

export const config = {
  port: Number(env('PORT') || 8080),
  githubRepoUrl: env('GITHUB_REPO_URL', 'https://github.com/Navendu-creator/infra-setup'),
  githubRepoRef: env('GITHUB_REPO_REF', 'main'),
  /** 'local' = built-in agent driven by a free/local LLM; 'cursor' = Cursor cloud agent. */
  agentProvider: (env('AGENT_PROVIDER') || (env('CURSOR_API_KEY') ? 'cursor' : 'local')) as 'local' | 'cursor',
  cursorApiKey: env('CURSOR_API_KEY'),
  cursorModel: env('CURSOR_MODEL', 'composer-2.5'),
  /**
   * 'openai' = any OpenAI-compatible API: the bundled llama.cpp server (llm/start.sh, default),
   * Gemini, Groq, OpenRouter... 'ollama' = Ollama's native API.
   */
  llmApi: (env('LLM_API') || 'openai') as 'ollama' | 'openai',
  llmBaseUrl: env('LLM_BASE_URL', 'http://127.0.0.1:8081/v1').replace(/\/+$/, ''),
  llmApiKey: env('LLM_API_KEY'),
  llmModel: env('LLM_MODEL', 'qwen3-1.7b'),
  /** Ollama only: context window to request. */
  llmNumCtx: Number(env('LLM_NUM_CTX') || 8192),
  llmMaxSteps: Number(env('LLM_MAX_STEPS') || 10),
  /** Minimum gap between LLM requests — keeps free tiers under their requests-per-minute limit. */
  llmMinIntervalMs: Number(env('LLM_MIN_INTERVAL_MS') || 0),
  llmRequestTimeoutMs: Number(env('LLM_REQUEST_TIMEOUT_MS') || 600_000),
  /** GitHub token (contents + pull requests write) used by the local agent to push and open the PR. */
  githubToken: env('GITHUB_TOKEN'),
  workspaceDir: env('WORKSPACE_DIR') || join(tmpdir(), 'debugassist-workspaces'),
  /** 'auto' uses bubblewrap when installed; 'bwrap' requires it; 'none' runs agent commands unsandboxed. */
  sandbox: (env('SANDBOX') || 'auto') as 'auto' | 'bwrap' | 'none',
  teamsWebhookUrl: env('TEAMS_WEBHOOK_URL'),
  /** Shared secret required on /api/webhooks/* when set. */
  intakeToken: env('INTAKE_TOKEN'),
  /** Optional hint for the agent, e.g. "npm test" or "terraform validate && tflint". */
  testCommand: env('TEST_COMMAND'),
  /** Abort the agent run after this many minutes. */
  agentTimeoutMinutes: Number(env('AGENT_TIMEOUT_MINUTES') || 45),
  dryRun: env('DRY_RUN', 'false').toLowerCase() === 'true',
};

export function assertRuntimeReady(): { ok: boolean; warnings: string[] } {
  const warnings: string[] = [];
  if (!config.teamsWebhookUrl) {
    warnings.push('TEAMS_WEBHOOK_URL missing — Teams tickets will be skipped');
  }
  if (config.agentProvider === 'cursor' && !config.cursorApiKey && !config.dryRun) {
    warnings.push('AGENT_PROVIDER=cursor but CURSOR_API_KEY missing — pipeline will dry-run');
  }
  if (
    config.agentProvider === 'local' &&
    config.llmApi === 'openai' &&
    !config.llmApiKey &&
    !/^https?:\/\/(127\.0\.0\.1|localhost)[:/]/.test(config.llmBaseUrl)
  ) {
    warnings.push('LLM_API_KEY missing for a hosted LLM API — requests will be rejected');
  }
  if (config.agentProvider === 'local' && !config.githubToken) {
    warnings.push('GITHUB_TOKEN missing — fixes are committed to a local branch only (no push / PR)');
  }
  if (!config.intakeToken) {
    warnings.push('INTAKE_TOKEN not set — /api/webhooks/* accepts unauthenticated requests');
  }
  return { ok: true, warnings };
}
