import { createHash } from 'node:crypto';
import { customAlphabet } from 'nanoid';
import { config } from '../config.js';
import { appendEvent, findOpenByFingerprint, hasIncident, saveIncident, updateIncident } from '../store.js';
import { runIncidentPipeline } from './agent.js';
import type { CreateIncidentInput, Incident } from '../types.js';

const nanoid = customAlphabet('0123456789ABCDEFGHJKLMNPQRSTUVWXYZ', 6);

function newIncidentId(): string {
  let id: string;
  do {
    id = `INC-${nanoid()}`;
  } while (hasIncident(id));
  return id;
}

/**
 * Normalizes volatile parts of an error message (ids, numbers, timestamps, hex, paths with line
 * numbers) so the same error logged many times produces the same fingerprint.
 */
export function fingerprintError(service: string, message: string): string {
  const normalized = message
    .toLowerCase()
    .replace(/\b[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}\b/g, '<uuid>')
    .replace(/\b0x[0-9a-f]+\b/g, '<hex>')
    .replace(/\d{4}-\d{2}-\d{2}[t ][\d:.]+z?/g, '<ts>')
    .replace(/\d+/g, '<n>')
    .replace(/\s+/g, ' ')
    .trim()
    .slice(0, 500);
  return createHash('sha256').update(`${service}\n${normalized}`).digest('hex').slice(0, 16);
}

export interface IntakeResult {
  incident: Incident;
  /** True when this report was attached to an already-open incident instead of starting a new pipeline. */
  deduplicated: boolean;
}

/**
 * Single entry point for every intake channel (web form, Teams, log/alert webhooks).
 * Creates the incident and starts the Teams ticket → agent → PR pipeline in the background.
 */
export function intakeIncident(input: CreateIncidentInput): IntakeResult {
  const source = input.source ?? 'web';

  if (input.fingerprint) {
    const existing = findOpenByFingerprint(input.fingerprint);
    if (existing) {
      updateIncident(existing.id, { occurrences: existing.occurrences + 1 });
      appendEvent(existing.id, 'intake', `Same error reported again from ${source} (pipeline already running)`);
      return { incident: existing, deduplicated: true };
    }
  }

  const now = new Date().toISOString();
  const incident: Incident = {
    id: newIncidentId(),
    title: input.title.slice(0, 300),
    description: (input.description ?? '').slice(0, 8000),
    severity: input.severity ?? 'P2',
    source,
    status: 'queued',
    repoUrl: config.githubRepoUrl,
    createdAt: now,
    updatedAt: now,
    service: input.service,
    environment: input.environment,
    fingerprint: input.fingerprint,
    occurrences: 1,
    timeline: [{ at: now, type: 'intake', message: `Incident received from ${source}` }],
  };

  saveIncident(incident);
  void runIncidentPipeline(incident.id);
  return { incident, deduplicated: false };
}
