import { config } from '../config.js';
import type { Incident } from '../types.js';

/**
 * Posts a ticket/status payload to the Power Automate → Teams webhook.
 * Flows typically map these fields into a Teams Adaptive Card / channel message.
 */
export async function notifyTeams(payload: Record<string, unknown>): Promise<{ ok: boolean; detail?: string }> {
  if (!config.teamsWebhookUrl) {
    return { ok: false, detail: 'TEAMS_WEBHOOK_URL not configured' };
  }

  try {
    const res = await fetch(config.teamsWebhookUrl, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(payload),
    });

    const text = await res.text().catch(() => '');
    if (!res.ok) {
      return { ok: false, detail: `Teams webhook HTTP ${res.status}: ${text.slice(0, 300)}` };
    }
    return { ok: true, detail: text.slice(0, 200) || 'ok' };
  } catch (err) {
    return { ok: false, detail: err instanceof Error ? err.message : String(err) };
  }
}

export function ticketPayload(incident: Incident) {
  const meta = [
    `Severity: ${incident.severity}`,
    `Source: ${incident.source}`,
    incident.service ? `Service: ${incident.service}` : '',
    incident.environment ? `Environment: ${incident.environment}` : '',
    `Repo: ${incident.repoUrl}`,
  ]
    .filter(Boolean)
    .join('\n');
  return {
    type: 'incident_ticket',
    title: `🎫 ${incident.id}: ${incident.title}`,
    text: `New DebugAssist ticket\n\n**${incident.id}** — ${incident.title}\n${meta}\n\n${incident.description}`,
    summary: `DebugAssist ticket ${incident.id}`,
    incidentId: incident.id,
    severity: incident.severity,
    status: incident.status,
    source: incident.source,
    service: incident.service ?? null,
    environment: incident.environment ?? null,
    repoUrl: incident.repoUrl,
    description: incident.description,
    createdAt: incident.createdAt,
    themeColor: incident.severity === 'P1' ? 'E85D4C' : '00A896',
  };
}

export function statusPayload(incident: Incident, headline: string) {
  const r = incident.report;
  const sections = [
    `Status: ${incident.status}`,
    incident.occurrences > 1 ? `Occurrences: ${incident.occurrences}` : '',
    incident.branch ? `Branch: ${incident.branch}` : '',
    incident.prUrl ? `PR: ${incident.prUrl}` : '',
    r?.rootCause ? `\n**Root cause**\n${r.rootCause}` : '',
    r?.fix ? `\n**Fix**\n${r.fix}` : '',
    r?.tests
      ? `\n**Tests** ${r.testsPassed === true ? '✅ passed' : r.testsPassed === false ? '❌ not passing' : ''}\n${r.tests}`
      : '',
    !r && incident.summary ? `\n${incident.summary}` : '',
    incident.error ? `\nError: ${incident.error}` : '',
  ].filter(Boolean);

  return {
    type: 'incident_update',
    title: headline,
    text: `${headline}\n\n**${incident.id}** — ${incident.title}\n${sections.join('\n')}`,
    summary: headline,
    incidentId: incident.id,
    severity: incident.severity,
    status: incident.status,
    branch: incident.branch ?? null,
    prUrl: incident.prUrl ?? null,
    rootCause: r?.rootCause ?? null,
    fix: r?.fix ?? null,
    tests: r?.tests ?? null,
    testsPassed: r?.testsPassed ?? null,
    summaryText: incident.summary ?? null,
    error: incident.error ?? null,
    updatedAt: incident.updatedAt,
    themeColor: incident.status === 'failed' || r?.testsPassed === false ? 'E85D4C' : '00A896',
  };
}
