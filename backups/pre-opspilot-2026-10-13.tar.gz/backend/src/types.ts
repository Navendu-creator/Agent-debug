export type IncidentStatus =
  | 'queued'
  | 'ticketed'
  | 'investigating'
  | 'fixing'
  | 'pr_ready'
  | 'failed'
  | 'completed';

export type IncidentSeverity = 'P1' | 'P2' | 'P3' | 'P4';

export interface IncidentEvent {
  at: string;
  type: string;
  message: string;
}

export interface IncidentReport {
  rootCause?: string;
  fix?: string;
  tests?: string;
  testsPassed?: boolean;
}

export interface Incident {
  id: string;
  title: string;
  description: string;
  severity: IncidentSeverity;
  source: string;
  status: IncidentStatus;
  repoUrl: string;
  createdAt: string;
  updatedAt: string;
  service?: string;
  environment?: string;
  /** Stable hash of service + normalized error; repeated log errors attach to the open incident. */
  fingerprint?: string;
  occurrences: number;
  agentId?: string;
  runId?: string;
  branch?: string;
  prUrl?: string;
  summary?: string;
  report?: IncidentReport;
  error?: string;
  timeline: IncidentEvent[];
}

export interface CreateIncidentInput {
  title: string;
  description?: string;
  severity?: IncidentSeverity;
  source?: string;
  service?: string;
  environment?: string;
  fingerprint?: string;
}
