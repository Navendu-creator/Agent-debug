import { Router, type RequestHandler } from 'express';
import { timingSafeEqual } from 'node:crypto';
import { config } from '../config.js';
import { fingerprintError, intakeIncident, type IntakeResult } from '../services/incidents.js';
import type { IncidentSeverity } from '../types.js';

/**
 * Optional shared-secret check for machine-to-machine intake. When INTAKE_TOKEN is set, callers
 * must send it as `Authorization: Bearer <token>`, `X-Intake-Token: <token>`, or `?token=<token>`.
 */
const requireIntakeToken: RequestHandler = (req, res, next) => {
  if (!config.intakeToken) return next();
  const header = req.get('authorization')?.replace(/^Bearer\s+/i, '') ?? req.get('x-intake-token');
  const supplied = header ?? (typeof req.query.token === 'string' ? req.query.token : '');
  const a = Buffer.from(supplied);
  const b = Buffer.from(config.intakeToken);
  if (a.length !== b.length || !timingSafeEqual(a, b)) {
    res.status(401).json({ error: 'Invalid or missing intake token' });
    return;
  }
  next();
};

function detectSeverity(text: string): IncidentSeverity {
  const hay = text.toUpperCase();
  if (/\b(P1|CRITICAL|FATAL|SEV\s*1|OUTAGE|EMERGENCY)\b/.test(hay)) return 'P1';
  if (/\b(P3|LOW|MINOR|WARN|WARNING)\b/.test(hay)) return 'P3';
  if (/\bP4\b/.test(hay)) return 'P4';
  return 'P2';
}

function str(value: unknown): string {
  if (value == null) return '';
  return typeof value === 'string' ? value.trim() : JSON.stringify(value);
}

function intakeResponse(result: IntakeResult) {
  return {
    ok: true,
    incidentId: result.incident.id,
    deduplicated: result.deduplicated,
    status: result.incident.status,
  };
}

export const webhooksRouter = Router();

webhooksRouter.use(requireIntakeToken);

/**
 * Accepts Microsoft Teams / Power Automate payloads.
 * Common shapes:
 *  - { text: "..." }
 *  - { title, text/body/description }
 *  - Adaptive Card / Bot Framework Activity { type, text, attachments }
 */
webhooksRouter.post('/teams', (req, res) => {
  const body = (req.body ?? {}) as Record<string, unknown>;
  const text =
    str(body.text ?? body.message ?? body.body ?? body.comment) || JSON.stringify(body).slice(0, 1500);
  const titleFromBody = str(body.title ?? body.subject);
  const firstLine = text.split('\n').map((l) => l.trim()).find(Boolean) || 'Teams-reported issue';

  const result = intakeIncident({
    title: titleFromBody || firstLine,
    description: text,
    severity: detectSeverity(`${titleFromBody}\n${text}`),
    source: 'teams',
  });

  res.status(202).json({ ...intakeResponse(result), message: 'Teams report accepted.' });
});

/** Health check used by Power Automate / monitoring */
webhooksRouter.get('/teams', (_req, res) => {
  res.json({
    ok: true,
    hint: 'POST JSON { title, text } or { text } to open an incident from Teams.',
  });
});

const TRIGGER_LEVELS = new Set(['error', 'fatal', 'critical', 'crit', 'alert', 'emergency', 'emerg']);

interface LogEvent {
  message: string;
  level: string;
  service: string;
  environment?: string;
  stack?: string;
  context: string;
  severity?: IncidentSeverity;
}

/** Generic structured log: { message, level?, service?, environment?, stack?, logs?, ... } */
function fromGenericLog(body: Record<string, unknown>): LogEvent {
  const message = str(body.message ?? body.msg ?? body.error ?? body.text);
  const extraLogs = Array.isArray(body.logs) ? body.logs.map(str).join('\n') : str(body.logs);
  const known = new Set(['message', 'msg', 'error', 'text', 'level', 'severity', 'service', 'app',
    'environment', 'env', 'stack', 'stackTrace', 'stacktrace', 'logs']);
  const rest = Object.fromEntries(Object.entries(body).filter(([k]) => !known.has(k)));

  return {
    message,
    level: str(body.level ?? body.severity ?? 'error').toLowerCase(),
    service: str(body.service ?? body.app) || 'unknown-service',
    environment: str(body.environment ?? body.env) || undefined,
    stack: str(body.stack ?? body.stackTrace ?? body.stacktrace) || undefined,
    context: [extraLogs, Object.keys(rest).length ? JSON.stringify(rest, null, 2) : '']
      .filter(Boolean)
      .join('\n\n'),
  };
}

/** Prometheus Alertmanager / Grafana alerting payload: { alerts: [{ status, labels, annotations }] } */
function fromAlerts(body: Record<string, unknown>): LogEvent[] {
  const alerts = (body.alerts as Array<Record<string, any>>) ?? [];
  return alerts
    .filter((a) => (a.status ?? 'firing') === 'firing')
    .map((a) => {
      const labels = (a.labels ?? {}) as Record<string, string>;
      const ann = (a.annotations ?? {}) as Record<string, string>;
      const sev = (labels.severity ?? 'critical').toLowerCase();
      return {
        message: `${labels.alertname ?? 'Alert'}: ${ann.summary ?? ann.description ?? ''}`.trim(),
        level: sev === 'warning' ? 'warn' : 'error',
        service: labels.service ?? labels.job ?? labels.namespace ?? 'unknown-service',
        environment: labels.env ?? labels.environment ?? labels.cluster,
        context: JSON.stringify({ labels, annotations: ann, startsAt: a.startsAt, generatorURL: a.generatorURL }, null, 2),
        severity: detectSeverity(sev),
      };
    });
}

/**
 * Log / alert intake. Point your log shipper, error tracker, or Alertmanager/Grafana contact point
 * here. Only error-level events open incidents; repeats of an open incident are deduplicated.
 * Body may be a single event, an array of events, or an Alertmanager-style { alerts: [...] }.
 */
webhooksRouter.post('/logs', (req, res) => {
  const body = req.body as unknown;
  const events: LogEvent[] = Array.isArray(body)
    ? body.map((b) => fromGenericLog((b ?? {}) as Record<string, unknown>))
    : body && typeof body === 'object' && Array.isArray((body as Record<string, unknown>).alerts)
      ? fromAlerts(body as Record<string, unknown>)
      : [fromGenericLog((body ?? {}) as Record<string, unknown>)];

  const results: Array<ReturnType<typeof intakeResponse>> = [];
  let ignored = 0;

  for (const ev of events.slice(0, 50)) {
    if (!ev.message || !TRIGGER_LEVELS.has(ev.level)) {
      ignored++;
      continue;
    }
    const description = [
      `Service: ${ev.service}`,
      ev.environment ? `Environment: ${ev.environment}` : '',
      `Level: ${ev.level}`,
      '',
      'Error:',
      ev.message,
      ev.stack ? `\nStack trace:\n${ev.stack}` : '',
      ev.context ? `\nContext:\n${ev.context}` : '',
    ]
      .filter((l) => l !== '')
      .join('\n');

    const firstLine = ev.message.split('\n')[0];
    results.push(
      intakeResponse(
        intakeIncident({
          title: `[${ev.service}] ${firstLine}`,
          description,
          severity: ev.severity ?? detectSeverity(`${ev.level}\n${ev.message}`),
          source: Array.isArray((body as Record<string, unknown>)?.alerts) ? 'alert' : 'logs',
          service: ev.service,
          environment: ev.environment,
          fingerprint: fingerprintError(ev.service, ev.message),
        }),
      ),
    );
  }

  res.status(202).json({ ok: true, accepted: results.length, ignored, incidents: results });
});
