import { Router } from 'express';
import { z } from 'zod';
import { getIncident, listIncidents } from '../store.js';
import { intakeIncident } from '../services/incidents.js';

const createSchema = z.object({
  title: z.string().min(3).max(300),
  description: z.string().max(8000).optional().default(''),
  severity: z.enum(['P1', 'P2', 'P3', 'P4']).optional().default('P2'),
  source: z.string().max(80).optional().default('web'),
  service: z.string().max(120).optional(),
  environment: z.string().max(60).optional(),
});

export const incidentsRouter = Router();

incidentsRouter.get('/', (_req, res) => {
  res.json({ incidents: listIncidents() });
});

incidentsRouter.get('/:id', (req, res) => {
  const incident = getIncident(req.params.id);
  if (!incident) {
    res.status(404).json({ error: 'Incident not found' });
    return;
  }
  res.json(incident);
});

incidentsRouter.post('/', (req, res) => {
  const parsed = createSchema.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.flatten() });
    return;
  }

  const { incident } = intakeIncident(parsed.data);

  res.status(202).json({
    ok: true,
    message: 'Incident accepted. Teams ticket + fix pipeline started.',
    incident,
  });
});
