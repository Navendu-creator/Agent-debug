# DebugAssist backend

Receives errors from the web UI, Microsoft Teams, log shippers or alerting, posts a ticket into your Teams channel, then runs an agent against your repo to investigate, fix, test, and open a PR with an RCA.

Two agent backends (`AGENT_PROVIDER`):

- **`local`** (default, free): built-in agent loop driven by any tool-calling LLM — Ollama on this
  machine, or a free API key (Gemini, Groq, OpenRouter). It clones the repo, investigates with
  read/search tools, edits files, runs validation commands inside a bubblewrap sandbox, commits to
  `debugassist/inc-xxxxxx`, pushes and opens the PR with `GITHUB_TOKEN`. Changes are only kept when a
  verification command succeeded after the last edit; otherwise only the RCA is committed (draft PR).
- **`cursor`**: Cursor cloud agent (paid, `CURSOR_API_KEY`), which clones/tests/PRs on Cursor's side.

## Flow

```
Web form / Teams message / log error / alert
    → POST /api/incidents | /api/webhooks/teams | /api/webhooks/logs
    → dedupe (repeated log errors attach to the open incident)
    → Teams channel ticket (Power Automate webhook)
    → agent (local free LLM or Cursor): investigate → reproduce → fix → run tests
        → branch debugassist/inc-xxxxxx + docs/incidents/INC-xxxxxx.md (RCA) → PR (autoCreatePR)
    → Teams update with root cause, fix, test results, branch, PR link
```

## Setup

```bash
cd backend
cp .env.example .env
# edit .env — add CURSOR_API_KEY, keep TEAMS_WEBHOOK_URL
npm install
npm run dev
# API: http://localhost:8080
```

### Required secrets

| Variable | Purpose |
|---|---|
| `TEAMS_WEBHOOK_URL` | Power Automate webhook that posts into your Teams channel |
| `LLM_*` | Free LLM for the local agent — see `.env.example` (Ollama, Gemini, Groq, OpenRouter) |
| `GITHUB_TOKEN` | Local agent: push branch + open PR (fine-grained, Contents + Pull requests write) |
| `CURSOR_API_KEY` | Only for `AGENT_PROVIDER=cursor` — [Cursor Dashboard → Integrations](https://cursor.com/dashboard/integrations) |
| `GITHUB_REPO_URL` | Repo to fix (default: `Navendu-creator/infra-setup`) |

Set `DRY_RUN=false` to run the real agent. On a CPU-only machine Ollama is slow (minutes per step);
a free Gemini key is much faster and better at code.

## Wire Teams → this API

Your webhook URL is **outbound** (this server → Teams). To also start fixes when someone posts in Teams:

1. Create a Power Automate flow: **When a new channel message is added**
2. Add action **HTTP** → `POST http://YOUR_PUBLIC_URL/api/webhooks/teams`
3. Body example:

```json
{
  "title": "@{triggerBody()?['subject']}",
  "text": "@{triggerBody()?['body']}"
}
```

For local testing, use [ngrok](https://ngrok.com) (`ngrok http 8080`) as `YOUR_PUBLIC_URL`, or just use the **Report error** form in the UI.

## Send log errors / alerts

`POST /api/webhooks/logs` accepts:

- a single event: `{ "level": "error", "service": "api", "environment": "prod", "message": "...", "stack": "...", "logs": ["..."] }`
- an array of events
- Prometheus Alertmanager / Grafana alerting payloads (`{ "alerts": [...] }`, only `firing` alerts)

Only `error` / `fatal` / `critical` levels open incidents; other levels are ignored. The same error
(same service + message with numbers/ids normalized) reported while an incident is still open increments
its `occurrences` instead of launching another agent.

```bash
curl -X POST http://localhost:8080/api/webhooks/logs \
  -H "Authorization: Bearer $INTAKE_TOKEN" -H 'Content-Type: application/json' \
  -d '{"level":"error","service":"api","message":"ECONNREFUSED redis:6379","stack":"..."}'
```

## Teams messages

Two payload types are POSTed to `TEAMS_WEBHOOK_URL` — map them in your Power Automate flow:

- `incident_ticket`: `title`, `text`, `incidentId`, `severity`, `source`, `service`, `environment`, `description`
- `incident_update`: `title`, `text`, `status`, `branch`, `prUrl`, `rootCause`, `fix`, `tests`, `testsPassed`, `error`

`text` is a ready-to-post markdown message if you don't want to build an Adaptive Card.

## API

- `POST /api/incidents` `{ "title", "description?", "severity?", "source?" }`
- `GET /api/incidents`
- `GET /api/incidents/:id`
- `POST /api/webhooks/teams` — Teams / Power Automate intake
- `POST /api/webhooks/logs` — log error / alert intake
- `GET /health`
