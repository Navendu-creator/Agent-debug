import { Navbar } from '@/components/Navbar';
import { Hero } from '@/components/Hero';
import { ReportError } from '@/components/ReportError';
import { Architecture } from '@/components/Architecture';
import { Workflow } from '@/components/Workflow';
import { TechStack } from '@/components/TechStack';
import { DemoDashboard } from '@/components/DemoDashboard';
import { Roadmap } from '@/components/Roadmap';
import { Footer } from '@/components/Footer';

function App() {
  return (
    <div className="min-h-screen bg-mist text-ink font-body">
      <Navbar />
      <Hero />
      <ReportError />
      <Architecture />
      <Workflow />
      <TechStack />
      <DemoDashboard />
      <Roadmap />
      <Footer />
    </div>
  );
}

export default App;
