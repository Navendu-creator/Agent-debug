/** @type {import('tailwindcss').Config} */
export default {
  content: ['./index.html', './src/**/*.{js,ts,jsx,tsx}'],
  theme: {
    extend: {
      colors: {
        ink: {
          DEFAULT: '#0c1222',
          soft: '#3d4a5c',
          muted: '#6b7a8f',
        },
        mist: '#eef3f8',
        paper: '#f7fafc',
        line: '#d5dee8',
        teal: {
          DEFAULT: '#00a896',
          deep: '#007f72',
          soft: '#e6f7f4',
        },
        coral: {
          DEFAULT: '#e85d4c',
          soft: '#fceceb',
        },
      },
      fontFamily: {
        display: ['Space Grotesk', 'system-ui', 'sans-serif'],
        body: ['DM Sans', 'system-ui', 'sans-serif'],
        mono: ['IBM Plex Mono', 'ui-monospace', 'monospace'],
      },
      boxShadow: {
        soft: '0 12px 40px -16px rgba(12, 18, 34, 0.18)',
        lift: '0 20px 50px -24px rgba(12, 18, 34, 0.22)',
      },
    },
  },
  plugins: [],
};
