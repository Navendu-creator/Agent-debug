#!/usr/bin/env bash
set -e

cd "$(dirname "$0")"
PIDS=()
trap 'kill "${PIDS[@]}" 2>/dev/null || true' EXIT INT TERM

port_busy() { ss -lnt | grep -q ":$1 "; }

# Local LLM (llama.cpp) for the free agent — only when the backend is configured to use it.
if grep -qE '^LLM_BASE_URL=http://(127\.0\.0\.1|localhost):8081' backend/.env 2>/dev/null ||
   ! grep -qE '^LLM_BASE_URL=' backend/.env 2>/dev/null; then
  if port_busy 8081; then
    echo "LLM server already running on 8081."
  elif [ -x llm/bin/llama-server ] && ls llm/models/*.gguf >/dev/null 2>&1; then
    echo "Starting local LLM (llama.cpp) on 8081..."
    bash llm/start.sh > llm/server.log 2>&1 &
    PIDS+=($!)
  else
    echo "Local LLM not installed — run: bash llm/setup.sh"
  fi
fi

if port_busy 8080; then
  echo "Backend already running on 8080."
else
  echo "Starting backend on 8080..."
  npm --prefix backend run dev &
  PIDS+=($!)
fi

npm --prefix project run dev -- --host 0.0.0.0 --port 5173
